﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Html;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.VisualStudio.Web.CodeGeneration.Contracts.Messaging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Forestry.Models;
//using Forestry.Models.ViewModels;
//using Forestry.Repositories;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;
using static System.Net.WebRequestMethods;
using System.Drawing;
using System.Security.Policy;
using System.Globalization;
using Microsoft.Extensions.Hosting.Internal;
using Microsoft.EntityFrameworkCore.Internal;
using Microsoft.Extensions.Hosting;
using Microsoft.VisualStudio.Web.CodeGeneration;
using PagedList;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization.Infrastructure;
using Microsoft.EntityFrameworkCore.Metadata;

namespace Forestry.Controllers
{

    public class UsuariosController : Controller
    {

        private readonly ContextoBaseDeDatos _context;

        public UsuariosController(ContextoBaseDeDatos context)
        {
            _context = context;
        }

/*---------VISUALIZAR USUARIOS---------------------------------------------*/
    //    [Authorize(Roles = "Administrador,Jefe")]
        [HttpGet]
        public IActionResult Personal()
        {
            var user = HttpContext.User;

            if (user.Identity.IsAuthenticated)
            {
                var roles = ((ClaimsIdentity)User.Identity).Claims
                    .Where(c => c.Type == ClaimTypes.Role)
                    .Select(c => c.Value);
                ViewBag.Rol = roles;
                // Ahora tienes una lista de roles del usuario autenticado
                // Puedes hacer lo que necesites con esta lista
            }


           
            // Consulta para obtener los primeros 10 registros
            var model = _context._Usuarios.Where(u => u.idUsuario >= 1 && u.idUsuario <= 10).ToList();

            var cantidadUsuarios = _context._Usuarios.Count();

            ViewBag.CantidadUsuarios = cantidadUsuarios;
            ViewBag.PagInicio = 1;
            ViewBag.PagFin = 10;

            return View("Personal", model);
        }

     //   [Authorize(Roles = "Administrador,Jefe")]
        [HttpPost]
        public IActionResult Personal(int PagInicio, int PagFin, string Accion, string Busqueda, string Rol)
        {
            ViewBag.Rol = Rol;
            if (Accion == "restar")
            {
                PagInicio = PagInicio - 10;
                PagFin = PagFin - 10;
            }
            else if (Accion == "sumar")
            {
                PagInicio = PagInicio + 10;
                PagFin = PagFin + 10;
            }
            else
            {
                PagInicio = PagInicio + 0;
                PagFin = PagFin + 0;
            }

            var model = _context._Usuarios.Where(u => u.idUsuario >= PagInicio && u.idUsuario <= PagFin).ToList();
            var cantidadUsuarios = _context._Usuarios.Count();

            ViewBag.CantidadUsuarios = cantidadUsuarios;
            ViewBag.PagInicio = PagInicio;
            ViewBag.PagFin = PagFin;

            return View("Personal", model);
        }

        [Authorize(Roles = "Administrador,Jefe")]
        [HttpPost]
        public IActionResult PersonalBusqueda(string Busqueda, string Estado, string Nombre, string ApPaterno, string ApMaterno)
        {
            string variableApMaterno = null; // Puede ser null
            string variableApPaterno = null;
            string variableNombre = null;
            if (Nombre != null)
            {
                variableNombre = Nombre.ToUpper();
            }
            if(ApPaterno != null)
            {
                variableApPaterno = ApPaterno.ToUpper();
            }
            if(ApMaterno != null)
            {
                variableApMaterno = ApMaterno.ToUpper(); // Puede ser null
            }
           
            string variableRol = Busqueda; // Puede ser null
            string variableEstado = Estado; // Puede ser null

            var usuariosQuery = _context._Usuarios.AsQueryable();

            if (variableRol != null)
            {
                usuariosQuery = usuariosQuery.Where(u => u.Rol == variableRol);
            }

            if (variableEstado != null)
            {
                usuariosQuery = usuariosQuery.Where(u => u.Estado == variableEstado);
            }

            if (variableNombre != null)
            {
                usuariosQuery = usuariosQuery.Where(u => u.Nombre == variableNombre);
            }

            if (variableApPaterno != null)
            {
                usuariosQuery = usuariosQuery.Where(u => u.ApPaterno == variableApPaterno);
            }

            if (variableApMaterno != null)
            {
                usuariosQuery = usuariosQuery.Where(u => u.ApMaterno == variableApMaterno);
            }

            if (variableNombre == null && variableEstado == null && variableRol == null && variableApPaterno == null && variableApMaterno == null)
            {
                usuariosQuery = usuariosQuery.Where(u => u.Nombre == "abcdefghijklmnopqrstuvwxz");
            }

            var  model = usuariosQuery.ToList();
            
             



           // ViewBag.CantidadUsuarios = cantidadUsuarios;

            return View("Personal", model);
        }

        [HttpPost]
        public IActionResult RecursosBusqueda(string Busqueda)
        {

            var model = _context.Recursos.Where(u => u.NombreRecurso == Busqueda);

            ViewBag.CatalogoRecursos = model;

            return View("CatalogoRecursos");
        }

        /*---------CREAR USUARIO-------------------------------------------------*/

        //   [Authorize(Roles = "Administrador")]
        [HttpGet]
        public IActionResult CrearUsuario()
        {
            return View("CrearUsuario");
        }

       // [Authorize(Roles = "Administrador")]
        [HttpPost]
        public IActionResult CrearUsuario(Usuarios usuarios, string Nombre, string ApPaterno, string ApMaterno, string NumeTel, string Rol, TimeSpan TrabajoInicio, TimeSpan TrabajoFin, List<string> DiasLaborales)
        {
            var user = HttpContext.User;

            if (user.Identity.IsAuthenticated)
            {
                var roles = ((ClaimsIdentity)User.Identity).Claims
                    .Where(c => c.Type == ClaimTypes.Role)
                    .Select(c => c.Value);
                ViewBag.Rol = roles;
                // Ahora tienes una lista de roles del usuario autenticado
                // Puedes hacer lo que necesites con esta lista
            }



            // Consulta para obtener los primeros 10 registros
            var model = _context._Usuarios.Where(u => u.idUsuario >= 1 && u.idUsuario <= 10).ToList();

            var cantidadUsuarios = _context._Usuarios.Count();

            ViewBag.CantidadUsuarios = cantidadUsuarios;
            ViewBag.PagInicio = 1;
            ViewBag.PagFin = 10;

            string diasLaboralesString = string.Join(", ", DiasLaborales);


            // Generar ID de 6 dígitos
            Random rnd = new Random();
            int id = rnd.Next(100000, 999999);

            usuarios.Nombre = Nombre.ToUpper();
            usuarios.ApMaterno = ApMaterno.ToUpper();
            usuarios.ApPaterno = ApPaterno.ToUpper();
            usuarios.NumeTel = NumeTel;
            usuarios.DiasLaborales = diasLaboralesString;
            usuarios.TrabajoInicio = TrabajoInicio;
            usuarios.TrabajoFin = TrabajoFin;

            // Construir nombre de usuario
            string nombreUsuario = usuarios.Nombre.Substring(0, 3) + usuarios.ApPaterno.Substring(0, 3) + id.ToString();

            // Generar contraseña aleatoria
            string caracteres = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890!@#$%^&*";
            StringBuilder contraseña = new StringBuilder();
            Random random = new Random();
            for (int i = 0; i < 8; i++)
            {
                contraseña.Append(caracteres[random.Next(caracteres.Length)]);
            }

            usuarios.Contrasena = contraseña.ToString();

            // Encriptar contraseña
            // Asignar valores al modelo de usuario
            usuarios.Usuario = nombreUsuario;
            usuarios.Estado = "disponible";
            usuarios.Rol = Rol;


            // Agregar usuario a la base de datos
            _context.Add(usuarios);
            _context.SaveChanges();

            TempData["SuccessMessage"] = "Cuenta creada con éxito.";

            return RedirectToAction ("Personal");
           // return View("Personal", model);
        }

        [HttpPost]

        public IActionResult AsignarIncendio(Incendio incendios, int idIncendio)
        {
           // Debug.WriteLine("ID INCENDIOOOOOO" + idIncendio);
            string rolUsuario = HttpContext.Session.GetString("RolUsuario");
            int idUsuario = HttpContext.Session.GetInt32("IdUsuario") ?? 0;

            var actIncendios = _context.Incendio.FirstOrDefault(u => u.idIncendio == idIncendio);


            if (rolUsuario == "Despacho")
            {
                var Despacho = _context._Usuarios.FirstOrDefault(u => u.idUsuario == idUsuario);
                string NombreDespacho = Despacho.Nombre + " " + Despacho.ApPaterno + " " + Despacho.ApMaterno;
             //   Debug.WriteLine("NOMBRE DEL DESPACHO" + NombreDespacho);
                actIncendios.NombreDespacho = NombreDespacho;
                Despacho.Estado = "ocupado";
                Despacho.Incendio = actIncendios;

                if(actIncendios.NombreDespacho != "Sin asignar" && actIncendios.NombreComando != "Sin asignar")
                {
                    actIncendios.Etapa = 2;
                }

                _context.SaveChanges();
                return View("~/Views/Incendio/Index.cshtml");
            }
            if(rolUsuario == "Comandos")
            {
                var Comandos = _context._Usuarios.FirstOrDefault(u => u.idUsuario == idUsuario);
                string NombreComandos = Comandos.Nombre + " " + Comandos.ApPaterno + " " + Comandos.ApMaterno;
                //   Debug.WriteLine("NOMBRE DEL DESPACHO" + NombreDespacho);
                actIncendios.NombreComando = NombreComandos;
                Comandos.Estado = "ocupado";
                Comandos.Incendio = actIncendios;

                if (actIncendios.NombreDespacho != "Sin asignar" && actIncendios.NombreComando != "Sin asignar")
                {
                    actIncendios.Etapa = 2;
                }

                _context.SaveChanges();
                return View("~/Views/Incendio/Index.cshtml");
            }



            _context.SaveChanges();

            return View("~/Views/Incendio/Index.cshtml");
        }

        [HttpGet]
        public IActionResult CatalogoRecursos()
        {
            var CatalogoRecursos = _context.Recursos?.
                Include(u => u.Incendio).ToList();

            ViewBag.CatalogoRecursos = CatalogoRecursos;

            return View("CatalogoRecursos");
        }


        
        [HttpPost]
        public IActionResult AgregarRecurso(string recurso, string NumSerie)
        {
            Recursos recursos = new Recursos();
            DateTime fechaActual = DateTime.Now;
            DateTime hora = DateTime.Today.Add(fechaActual.TimeOfDay);

            recursos.NombreRecurso = recurso;
            recursos.NumSerie = NumSerie;
            recursos.Estado = "Lleno";
            recursos.FechaCreada = hora;

            _context.Add(recursos);
            _context.SaveChanges();


            return RedirectToAction("CatalogoRecursos");
        }
        

        [HttpPost]
        public IActionResult EliminarRecurso(int IdRecursos)
        {
            // Buscar el recurso que coincida con el IdRecursos
            var recursoAEliminar = _context.Recursos.FirstOrDefault(u => u.IdRecursos == IdRecursos);

            if (recursoAEliminar != null)
            {
                // Eliminar el recurso
                _context.Recursos.Remove(recursoAEliminar);

                // Guardar los cambios en la base de datos
                _context.SaveChanges();
            }

            // Redirigir a la vista de catálogo de recursos después de eliminar
            return RedirectToAction("CatalogoRecursos");
        }

        [HttpGet]
        public IActionResult CatalogoTrabajadores()
        {
            
            var JefeComandos = _context._Usuarios?
                .Where(u => u.Rol == "Comandos").ToList();

            var CatalogoRecursos = _context.Personal?.Include(p => p.Usuarios).ToList();

            ViewBag.CatalogoRecursos = CatalogoRecursos;
            ViewBag.JefeComandos = JefeComandos;

            return View("CatalogoTrabajadores");
        }

        [HttpPost]
        public IActionResult AgregarTrabajador(string Nombre, string ApPaterno, string ApMaterno, string Turno, int idUsuario)
        {
            Personal trabajador = new Personal();
            DateTime fechaActual = DateTime.Now;
            DateTime hora = DateTime.Today.Add(fechaActual.TimeOfDay);

            var comando = _context._Usuarios.FirstOrDefault(u => u.idUsuario == idUsuario);

            trabajador.Nombre = Nombre;
            trabajador.ApPaterno = ApPaterno;
            trabajador.ApMaterno = ApMaterno;
            trabajador.Turno = Turno;
            trabajador.Usuarios = comando;
            trabajador.FechaCreada = hora;

            _context.Add(trabajador);
            _context.SaveChanges();


            return RedirectToAction("CatalogoTrabajadores");
        }

        [HttpPost]
        public IActionResult EliminarTrabajador(int IdTrabajador)
        {
            // Buscar el recurso que coincida con el IdRecursos
            var recursoAEliminar = _context.Personal.FirstOrDefault(u => u.IdTrabajador == IdTrabajador);

            if (recursoAEliminar != null)
            {
                // Eliminar el recurso
                _context.Personal.Remove(recursoAEliminar);

                // Guardar los cambios en la base de datos
                _context.SaveChanges();
            }

            // Redirigir a la vista de catálogo de recursos después de eliminar
            return RedirectToAction("CatalogoTrabajadores");
        }
    }
}
