﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Html;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.VisualStudio.Web.CodeGeneration.Contracts.Messaging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Forestry.Models;
//using Forestry.Models.ViewModels;
//using Forestry.Repositories;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;
using static System.Net.WebRequestMethods;
using System.Drawing;
using System.Security.Policy;
using System.Globalization;
using Microsoft.Extensions.Hosting.Internal;
using Microsoft.EntityFrameworkCore.Internal;
using Microsoft.AspNetCore.Mvc.ViewEngines;

namespace Forestry.Controllers
{
    public class HomeController : Controller
    {

        private readonly ILogger<HomeController> _logger;
        private readonly ContextoBaseDeDatos _context;
        private readonly IWebHostEnvironment _hostEnvironment;

        public HomeController(ILogger<HomeController> logger, ContextoBaseDeDatos context, IWebHostEnvironment hostEnvironment)
        {
            _logger = logger;
            _context = context;
            _hostEnvironment = hostEnvironment;

        }

        public IActionResult Index()
        {

            return View();
        }


        /*------------MÉTODOS DEL LOGIN--------------------*/
        [HttpGet]
        public IActionResult Login()
        {
            /*
            if (User.Identity.IsAuthenticated)
            {

               // return Redirect("CrearUsuario");
               return Redirect("Login");
            }
            else
            {
                //ViewBag.Error = String.IsNullOrEmpty(HttpContext.Request.Query["error"]) ? false : true;
                //ViewBag.Completo = String.IsNullOrEmpty(HttpContext.Request.Query["completo"]) ? false : true;
                return View();
            }
     */
            return View();
        }

        [HttpPost]
        public IActionResult Login(string _Usuario, string password)
        {
            string Rol = string.Empty;
            string Carpeta = string.Empty;
            string Vista = string.Empty;
            var usuario = _context._Usuarios.FirstOrDefault(u => u.Usuario == _Usuario);

            if (usuario == null || usuario.Contrasena != password)
            {
                ViewBag.Error = "Usuario o contraseña incorrectos.";
                return RedirectToAction("Login", new { error = true });
            }

            if (usuario != null && usuario.Contrasena == password)
            {
                if (usuario.Rol == "Administrador")
                {
                    Rol = "Administrador";
                    Carpeta = "Usuarios";
                    Vista = "Personal";
                }
                else if (usuario.Rol == "Telefono")
                {
                    Rol = "Telefono";
                    Carpeta = "Reportes";
                    Vista = "Reportes";
                }
                else if (usuario.Rol == "Jefe")
                {
                    Rol = "Jefe";
                    Carpeta = "Reportes";
                    Vista = "Incendios";
                }
                else if (usuario.Rol == "Asignador")
                {
                    Rol = "Asignador";
                    Carpeta = "Reportes";
                    Vista = "Incendios";
                }
                else if (usuario.Rol == "Despacho" && usuario.Estado == "disponible")
                {
                    
                        return RedirectToAction("Login", new { mensaje = "No tienes incendios asignados" });
                   
                }
                else if (usuario.Rol == "Comandos" && usuario.Estado == "disponible")
                {
                    
                        return RedirectToAction("Login", new { mensaje = "No tienes incendios asignados" });
                    

                }
                else if (usuario.Rol == "Despacho" && usuario.Estado == "ocupado")
                {
                    Rol = "Despacho";
                    Carpeta = "Incendio";
                    Vista = "Index";
                }
                else if (usuario.Rol == "Comandos" && usuario.Estado == "ocupado")
                {
                    Rol = "Despacho";
                    Carpeta = "Incendio";
                    Vista = "Index";
                }

                var autorizacion = new List<Claim>()
        {
            new Claim(ClaimTypes.Role, Rol),
            new Claim("Usuario", usuario.Usuario.ToString()),
            new Claim("Autenticado", "SI"),
        };

                var identidad = new ClaimsIdentity(autorizacion, "AutorizacionesClaim");
                var principal = new ClaimsPrincipal(new[] { identidad });

                HttpContext.SignInAsync(principal, new AuthenticationProperties
                {
                    ExpiresUtc = DateTime.UtcNow.AddMinutes(30) // Sesión expira en 30 minutos
                });

                HttpContext.Session.SetInt32("IdUsuario", usuario.idUsuario);
                HttpContext.Session.SetString("RolUsuario", usuario.Rol);
                HttpContext.Session.SetString("EstadoUsuario", usuario.Estado);
                HttpContext.Session.SetString("NombreUsuario", usuario.Nombre + " " + usuario.ApPaterno + " " + usuario.ApMaterno);

                return RedirectToAction(Vista, Carpeta, Rol);
            }

            return View(Rol);
        }



        /*-----------------MÉTODOS DEL JEFE DE DESPACHO--------------------*/

        [HttpGet]
        public IActionResult RegistroIncendios()
        {
            return View("JefeDespacho/RegistroIncendios");
        }


        /*---------------------------MÉTODOS DEL PERSONAL DE DESPACHO-----------------------------*/
        [HttpGet]
        public IActionResult IndexDespacho()
        {
            return View("Despacho/IndexDespacho");
        }

        /*---------------------------MÉTODOS DEL PERSONAL DE DESPACHO-----------------------------*/
        [HttpGet]
        public IActionResult Bitacoras()
        {
           // var primerUsuario = _context._Usuarios.FirstOrDefault();
            // Console.WriteLine($"ID: {primerUsuario.IdUsuario}, Nombre: {primerUsuario.NombreUsuario}");
            return View("Comandos/Bitacoras");
        }

        [HttpGet]
        public IActionResult BitacoraChequeoPlaneacion()
        {
            return View("Comandos/BitacoraChequeoPlaneacion");
        }

        [HttpGet]
        public IActionResult BitacoraStatusSituacion()
        {
            return View("Comandos/BitacoraStatusSituacion");
        }

        [HttpGet]
        public IActionResult BitacoraTamanoIncendio()
        {
            return View("Comandos/BitacoraTamanoIncendio");
        }

        [HttpGet]
        public IActionResult BitacoraVerificacionCI()
        {
            return View("Comandos/BitacoraVerificacionCI");
        }

        [HttpGet]
        public IActionResult BitacoraRevisionPosterior()
        {
            return View("Comandos/BitacoraRevisionPosterior");
        }

        [Authorize]
        [HttpGet]
        public IActionResult Recursos()
        {
            return View("Comandos/Recursos");
        }

        [HttpGet]
        public IActionResult Mapa()
        {
            return View("Comandos/Mapa");
        }

        /*-----------------AGENTE TELEFÓNICO----------------------*/


        [HttpGet]
        public IActionResult IncendiosActivos()
        {
            return View("IncendiosActivos");
        }

        /*-----------------OTROS-----------------------*/

        [Authorize]
        public IActionResult Privacy()
        {
            return View();
            
        }

        public async Task<IActionResult> SignOut()
        {
            await
            HttpContext.SignOutAsync();
            return Redirect("/Home/Login");
        }

        /*
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
        */
    }
}
