﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Html;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.VisualStudio.Web.CodeGeneration.Contracts.Messaging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Forestry.Models;
//using Forestry.Models.ViewModels;
//using Forestry.Repositories;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;
using static System.Net.WebRequestMethods;
using System.Drawing;
using System.Security.Policy;
using System.Globalization;
using Microsoft.Extensions.Hosting.Internal;
using Microsoft.EntityFrameworkCore.Internal;
using Microsoft.Extensions.Hosting;
using Microsoft.VisualStudio.Web.CodeGeneration;
using PagedList;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization.Infrastructure;
using System.Linq;
using Forestry.ViewModels;

namespace Forestry.Controllers
{

    public class IncendioController : Controller
    {

        private readonly ContextoBaseDeDatos _context;

        public IncendioController(ContextoBaseDeDatos context)
        {
            _context = context;
        }

        
        [HttpGet]
        public IActionResult Mapa()
        {
            int idUsuario = HttpContext.Session.GetInt32("IdUsuario") ?? 0;


            var usuario = _context._Usuarios.Include(u => u.Incendio).FirstOrDefault(u => u.idUsuario == idUsuario);
            if (usuario == null)
            {
                return NotFound("Usuario no encontrado.");
            }
            // CON JSON
            //var Mapa = _context.Actualizacion.LastOrDefault(u => u.Incendio == usuario.Incendio) ?? new Actualizacion();

            //SIN JASON
            /*
            var actualizacion = _context.Actualizacion
            .Where(u => u.idIncendio == usuario.Incendio.idIncendio && (u.Tipo == "Mapa" || u.Tipo=="Inicial"))
            .Select(a => new
            {
                a.Latitud,
                a.Longitud,
                a.Radio,
                a.Accion
            })
            .ToList();
            */

            var actualizacion = _context.Actualizacion
            .Where(u => u.Incendio == usuario.Incendio && (u.Tipo == "Mapa" || u.Tipo == "Inicial")).ToList();

            ViewBag.Actualizacion = actualizacion;

            //  var Mapa = _context.Actualizacion.Where(u => u.Incendio == usuario.Incendio && u.Tipo == "Mapa").ToList();

            return View("Mapa");
        }

        [HttpGet]
        public IActionResult Index()
        {
            int idUsuario = HttpContext.Session.GetInt32("IdUsuario") ?? 0;
            /*
            var usuario = _context._Usuarios.Include(u => u.Incendio).FirstOrDefault(u => u.idUsuario == idUsuario);
            var BitacoraChequeoPlaneacion = _context.BitacoraChequeoYPlaneacion.FirstOrDefault(u => u.Incendio == usuario.Incendio);
            var BitacoraStatusSitiacion = _context.BitacoraStatus.FirstOrDefault(u => u.Incendio == usuario.Incendio);
            var BitacoraTamanoIncendio = _context.BitacoraTamanoIncendio.FirstOrDefault(u => u.Incendio == usuario.Incendio);
            var BitacoraVerficacionCI = _context.BitacoraVerificacionCI.FirstOrDefault(u => u.Incendio == usuario.Incendio);
            var BitacoraMedidaInicial = _context.BitacoraMedidaInicial.FirstOrDefault(u => u.Incendio == usuario.Incendio);

            var BitacoraActualizacion = _context.Actualizacion.Where(u => u.Incendio == usuario.Incendio).ToList();
            var BitacoraRecursos = _context.BitacoraRecursos.Where(u => u.Incendio == usuario.Incendio).ToList();
            var BitacoraRelacionTrabajo = _context.BitacoraRelacionTrabajo.Where(u => u.Incendio == usuario.Incendio).ToList();
            */

            var usuario = _context._Usuarios.Include(u => u.Incendio).FirstOrDefault(u => u.idUsuario == idUsuario);
            if (usuario.Incendio == null)
            {
                return RedirectToAction("SignOut", "Home");
            }
            var incendio = _context.Incendio.FirstOrDefault(u => u.idIncendio == usuario.Incendio.idIncendio);
           
            var comando = _context._Usuarios.FirstOrDefault(u => u.Incendio == incendio && u.Rol == "Comandos");

            var RecursosTotales = _context.Recursos.Where(u => u.Incendio == null);
            var actRecursos = _context.ActualizacionRecursos.Where(u => u.Incendio == usuario.Incendio);
            var RecursosPrestados = _context.Recursos.Where(u => u.Incendio == usuario.Incendio && u.Estado == "Lleno");
            var Trabajadores = _context.Personal.Where(u => u.Usuarios == comando);

            var BitacoraChequeoPlaneacion = _context.BitacoraChequeoYPlaneacion.FirstOrDefault(u => u.Incendio == usuario.Incendio) ?? new BitacoraChequeoYPlaneacion();
            var BitacoraStatusSitiacion = _context.BitacoraStatus.FirstOrDefault(u => u.Incendio == usuario.Incendio) ?? new BitacoraStatus();
            var BitacoraTamanoIncendio = _context.BitacoraTamanoIncendio.FirstOrDefault(u => u.Incendio == usuario.Incendio) ?? new BitacoraTamanoIncendio();
            var BitacoraVerficacionCI = _context.BitacoraVerificacionCI.FirstOrDefault(u => u.Incendio == usuario.Incendio) ?? new BitacoraVerificacionCI();
            var BitacoraMedidaInicial = _context.BitacoraMedidaInicial.FirstOrDefault(u => u.Incendio == usuario.Incendio) ?? new BitacoraMedidaInicial();

            var BitacoraActualizacion = _context.Actualizacion.Where(u => u.Incendio == usuario.Incendio && u.Tipo=="accion").ToList();
            var BitacoraRecursos = _context.BitacoraRecursos.Where(u => u.Incendio == usuario.Incendio).ToList();
            var BitacoraRelacionTrabajo = _context.BitacoraRelacionTrabajo.Where(u => u.Incendio == usuario.Incendio).ToList();

            var RecursosAsignados = _context.Recursos?.Where(u => u.Incendio == incendio && u.Estado == "Lleno").ToList();
            var RecursosSolicitados = _context.RecursosSolicitados?.Where(u => u.Incendio == incendio);

            ViewBag.RecursosSolicitados = RecursosSolicitados;
            ViewBag.RecursosAsignados = RecursosAsignados;
            ViewBag.CatalogoTrabajadores = Trabajadores;
            ViewBag.CatalogoRecursos = RecursosPrestados;
            ViewBag.ActRecursos = actRecursos;
            ViewBag.RecursosTotales = RecursosTotales;
            ViewBag.Usuario = usuario;
            ViewBag.Incendio = incendio;
            ViewBag.BitacoraChequeoPlaneacion = BitacoraChequeoPlaneacion;
            ViewBag.BitacoraStatusSitiacion = BitacoraStatusSitiacion;
            ViewBag.BitacoraTamanoIncendio = BitacoraTamanoIncendio;
            ViewBag.BitacoraVerficacionCI = BitacoraVerficacionCI;
            ViewBag.BitacoraMedidaInicial = BitacoraMedidaInicial;

            ViewBag.BitacoraActualizacion = BitacoraActualizacion;
            ViewBag.BitacoraRecursos = BitacoraRecursos;
            ViewBag.BitacoraRelacionTrabajo = BitacoraRelacionTrabajo;

            return View("Index");
        }

        [HttpGet]
        public IActionResult AgregarRecursos()
        {
            int idUsuario = HttpContext.Session.GetInt32("IdUsuario") ?? 0;
            var usuario = _context._Usuarios.Include(u => u.Incendio).FirstOrDefault(u => u.idUsuario == idUsuario);
            var incendio = _context.Incendio.FirstOrDefault(u => u.idIncendio == usuario.Incendio.idIncendio);

            var model = _context.Recursos?.Where(u => u.Incendio == null);
            ViewBag.CatalogoRecursos = model;

            var RecursosAsignados = _context.Recursos?.Where(u => u.Incendio == incendio).ToList();
            ViewBag.RecursosAsignados = RecursosAsignados;

            return View("AgregarRecursos");
        }

        [HttpPost]
        public IActionResult AgregarRecursos(int idRecurso, string NombreRecurso)
        {
            ActualizacionRecursos actRecursos = new ActualizacionRecursos();
            int idUsuario = HttpContext.Session.GetInt32("IdUsuario") ?? 0;
            var usuario = _context._Usuarios.Include(u => u.Incendio).FirstOrDefault(u => u.idUsuario == idUsuario);
            var incendio = _context.Incendio.FirstOrDefault(u => u.idIncendio == usuario.Incendio.idIncendio);

            incendio.Etapa = 3;

            var actCatalogo = _context.Recursos.FirstOrDefault(u => u.IdRecursos == idRecurso);

            DateTime fechaActual = DateTime.Now;
            DateTime hora = DateTime.Today.Add(fechaActual.TimeOfDay);

            var recursos = _context.Recursos.FirstOrDefault(u => u.IdRecursos == idRecurso);

            if(recursos.Incendio == null)
            {
                recursos.Incendio = incendio;

                actRecursos.NombreRecurso = recursos.NombreRecurso;
                actRecursos.NumSerie = recursos.NumSerie;
                actRecursos.Estado = recursos.Estado;
                actRecursos.Latitud = recursos.Latitud;
                actRecursos.Longitud = recursos.Longitud;
                actRecursos.FechaCreada = hora;
                actRecursos.Incendio = incendio;

                _context.Add(actRecursos);
                _context.SaveChanges();
            }

            var CatalogoRecursos = _context.Recursos.Where(u => u.NombreRecurso == NombreRecurso && u.Incendio == null);
            var RecursosAsignados = _context.Recursos?.Where(u => u.Incendio == incendio).ToList();

            ViewBag.RecursosAsignados = RecursosAsignados;
            ViewBag.CatalogoRecursos = CatalogoRecursos;

            return View("AgregarRecursos");
        }

        [HttpPost]
        public IActionResult RecursosBusqueda(string Busqueda)
        {
            int idUsuario = HttpContext.Session.GetInt32("IdUsuario") ?? 0;
            var usuario = _context._Usuarios.Include(u => u.Incendio).FirstOrDefault(u => u.idUsuario == idUsuario);
            var incendio = _context.Incendio.FirstOrDefault(u => u.idIncendio == usuario.Incendio.idIncendio);
            var RecursosAsignados = _context.Recursos?.Where(u => u.Incendio == incendio).ToList();
            ViewBag.RecursosAsignados = RecursosAsignados;

            var model = _context.Recursos.Where(u => u.NombreRecurso == Busqueda);
            ViewBag.CatalogoRecursos = model;

            return View("AgregarRecursos");
        }

        [HttpPost]
        public IActionResult EliminarRecursos(int idRecurso, string NombreRecurso)
        {
            int idUsuario = HttpContext.Session.GetInt32("IdUsuario") ?? 0;
            var usuario = _context._Usuarios.Include(u => u.Incendio).FirstOrDefault(u => u.idUsuario == idUsuario);
            var incendio = _context.Incendio.FirstOrDefault(u => u.idIncendio == usuario.Incendio.idIncendio);

            var actCatalogo = _context.Recursos.FirstOrDefault(u => u.IdRecursos == idRecurso);

            DateTime fechaActual = DateTime.Now;
            DateTime hora = DateTime.Today.Add(fechaActual.TimeOfDay);

            var recursos = _context.Recursos.FirstOrDefault(u => u.IdRecursos == idRecurso);
            var actRecursos = _context.ActualizacionRecursos.FirstOrDefault(u => u.NumSerie == recursos.NumSerie);

            recursos.Incendio = null;

            if(actRecursos != null)
            {
                _context.ActualizacionRecursos.Remove(actRecursos);
            }

            _context.SaveChanges();
            

            var CatalogoRecursos = _context.Recursos.Where(u => u.NombreRecurso == NombreRecurso);
            ViewBag.CatalogoRecursos = CatalogoRecursos;

            return RedirectToAction("AgregarRecursos");
        }


        [HttpPost]
        public IActionResult SolicitarRecursos(string NombreRecurso, int CantidadSolicitada)
        {
            RecursosSolicitados recursos = new RecursosSolicitados();

            int idUsuario = HttpContext.Session.GetInt32("IdUsuario") ?? 0;
            var usuario = _context._Usuarios.Include(u => u.Incendio).FirstOrDefault(u => u.idUsuario == idUsuario);
            var incendio = _context.Incendio.FirstOrDefault(u => u.idIncendio == usuario.Incendio.idIncendio);


            DateTime fechaActual = DateTime.Now;
            DateTime hora = DateTime.Today.Add(fechaActual.TimeOfDay);

            //Asignación de valores
            recursos.NombreRecurso = NombreRecurso;
            recursos.FechaCreada = hora;
            recursos.CantidadSolicitada = CantidadSolicitada;
            recursos.Incendio = incendio;


            _context.Add(recursos);
            _context.SaveChanges();
            return RedirectToAction("Index");
        }

        [HttpGet]
        public IActionResult Recursos()
        {
            return View("Recursos");
        }

        [HttpGet]
        public IActionResult BitacoraChequeoPlaneacion()
        {
            return View("BitacoraChequeoPlaneacion");
        }

        [HttpGet]
        public IActionResult BitacoraRevisionPosterior()
        {
            return View("BitacoraRevisionPosterior");
        }

        [HttpGet]
        public IActionResult BitacoraStatusSituacion()
        {
            return View("BitacoraStatusSituacion");
        }

        [HttpGet]
        public IActionResult BitacoraTamanoIncendio()
        {
            return View("BitacoraTamanoIncendio");
        }

        [HttpGet]
        public IActionResult BitacoraVerificacionCI()
        {
            return View("BitacoraVerificacionCI");
        }

        [HttpPost]
        public IActionResult GuardarAccion(Actualizacion act, Incendio incendios,string Acciones)
        {
            int idUsuario = HttpContext.Session.GetInt32("IdUsuario") ?? 0;
            DateTime fechaActual = DateTime.Now;
            DateTime hora = DateTime.Today.Add(fechaActual.TimeOfDay);
            act.FechaAccion = hora;

            var usuario = _context._Usuarios.Include(u => u.Incendio).FirstOrDefault(u => u.idUsuario == idUsuario);
            act.Incendio = usuario.Incendio;

            act.Accion = Acciones;
            act.Tipo = "accion";

            _context.Add(act);
            _context.SaveChanges();
            return RedirectToAction("Index");
            //return View("Index");
        }

        [HttpPost]
        public IActionResult GuardarMapa(Actualizacion act, Incendio incendios, string Radio, string Latitud, string Longitud, string Recurso)
        {
            int idUsuario = HttpContext.Session.GetInt32("IdUsuario") ?? 0;
            DateTime fechaActual = DateTime.Now;
            DateTime hora = DateTime.Today.Add(fechaActual.TimeOfDay);

            decimal convertLatitud = Convert.ToDecimal(Latitud);
            decimal convertLongitud = Convert.ToDecimal(Longitud);

            var usuario = _context._Usuarios.Include(u => u.Incendio).FirstOrDefault(u => u.idUsuario == idUsuario);
            if (decimal.TryParse(Latitud, out decimal latitudDecimal) &&
                 decimal.TryParse(Longitud, out decimal longitudDecimal) &&
                 float.TryParse(Radio, out float radioFloat))
            {
                act.Incendio = usuario.Incendio;
                act.Latitud = Math.Round(latitudDecimal, 6); ;
                act.Longitud = Math.Round(longitudDecimal, 6);
                act.Radio = radioFloat;
                act.FechaAccion = DateTime.Now;
                act.Accion = Recurso;
                act.Tipo = "Mapa";
              //  act.Tipo = !string.IsNullOrEmpty(Radio) ? "Círculo" : "Marcador";


                _context.Add(act);
                _context.SaveChanges();
            }
            else
            {
                // Manejo de error en caso de conversión fallida
                ModelState.AddModelError(string.Empty, "Latitud, Longitud o Radio no tienen un formato válido.");
                return RedirectToAction("Mapa"); // Asegúrate de que esta vista exista
            }

            return RedirectToAction("Mapa");
           

      
        }

        [HttpPost]
        public IActionResult GuardarTrabajo(string Recurso, DateTime FechaInicio, DateTime FechaTermino, double HorasTrabajadas, double HorasDescansadas)
        {
            BitacoraRelacionTrabajo recursos = new BitacoraRelacionTrabajo();
            Incendio incendios = new Incendio();

            int idUsuario = HttpContext.Session.GetInt32("IdUsuario") ?? 0;
            DateTime fechaActual = DateTime.Now;
            DateTime hora = DateTime.Today.Add(fechaActual.TimeOfDay);
            recursos.FechaCreada = hora;

            var usuario = _context._Usuarios.Include(u => u.Incendio).FirstOrDefault(u => u.idUsuario == idUsuario);
   
            recursos.Incendio = usuario.Incendio;
            recursos.Recurso = Recurso;
            recursos.FechaInicio = FechaInicio;
            recursos.FechaTermino = FechaTermino;
            recursos.HorasTrabajadas = HorasTrabajadas;
            recursos.HorasDescansadas = HorasDescansadas;

            _context.Add(recursos);
            _context.SaveChanges();

            return RedirectToAction("Index");
           // return View("Index");
        }


        [HttpPost]
        public IActionResult BitacoraChequeoPlaneacion(BitacoraChequeoYPlaneacion act, Incendio incendios)
        {
            int idUsuario = HttpContext.Session.GetInt32("IdUsuario") ?? 0;
            DateTime fechaActual = DateTime.Now;
            DateTime hora = DateTime.Today.Add(fechaActual.TimeOfDay);
            act.FechaCreada = hora;

            var usuario = _context._Usuarios.Include(u => u.Incendio).FirstOrDefault(u => u.idUsuario == idUsuario);
            act.Incendio = usuario.Incendio;

            var actIncendio = _context.Incendio.FirstOrDefault(u => u.idIncendio == usuario.Incendio.idIncendio);

            actIncendio.Etapa += 1;

            _context.Add(act);
            _context.SaveChanges();
            return RedirectToAction("Index");
            //return View("Index");
        }

        [HttpPost]
        public IActionResult BitacoraRevisionPosterior(Incendio incendios)
        {
            BitacoraRevisionPosterior act = new BitacoraRevisionPosterior();

            int idUsuario = HttpContext.Session.GetInt32("IdUsuario") ?? 0;


            DateTime fechaActual = DateTime.Now;
            DateTime hora = DateTime.Today.Add(fechaActual.TimeOfDay);
            act.FechaCreada = hora;

            var usuario = _context._Usuarios.Include(u => u.Incendio).FirstOrDefault(u => u.idUsuario == idUsuario);
            act.Incendio = usuario.Incendio;

            var actIncendio = _context.Incendio.FirstOrDefault(u => u.idIncendio == usuario.Incendio.idIncendio);

            actIncendio.Etapa = 11;
            actIncendio.FechaFin = hora;

            var Despacho = _context._Usuarios.FirstOrDefault(u => u.Incendio == usuario.Incendio && u.Rol == "Despacho");
            Despacho.Estado = "disponible";
            Despacho.Incendio = null;

            var Comando = _context._Usuarios.FirstOrDefault(u => u.Incendio == usuario.Incendio && u.Rol == "Comandos");
            Comando.Estado = "disponible";
            Comando.Incendio = null;

            var recursos = _context.Recursos.Where(u => u.Incendio == actIncendio);
            foreach (var recurs in recursos)
            {
                recurs.Incendio = null;
                recurs.Estado = "Lleno";
            }
       
            _context.Add(act);
            _context.SaveChanges();
            return RedirectToAction("SignOut", "Home");
            //return View("Index");
        }

        [HttpPost]
        public IActionResult BitacoraStatusSituacion(BitacoraStatus act, Incendio incendios)
        {
            int idUsuario = HttpContext.Session.GetInt32("IdUsuario") ?? 0;
            DateTime fechaActual = DateTime.Now;
            DateTime hora = DateTime.Today.Add(fechaActual.TimeOfDay);
            act.FechaCreada = hora;

            var usuario = _context._Usuarios.Include(u => u.Incendio).FirstOrDefault(u => u.idUsuario == idUsuario);
            act.Incendio = usuario.Incendio;

            var actIncendio = _context.Incendio.FirstOrDefault(u => u.idIncendio == usuario.Incendio.idIncendio);

            actIncendio.Etapa += 1;

            _context.Add(act);
            _context.SaveChanges();

            return RedirectToAction("Index");
            //return View("Index");
        }

        [HttpPost]
        public IActionResult BitacoraTamanoIncendio(BitacoraStatus act, Incendio incendios)
        {
            int idUsuario = HttpContext.Session.GetInt32("IdUsuario") ?? 0;
            DateTime fechaActual = DateTime.Now;
            DateTime hora = DateTime.Today.Add(fechaActual.TimeOfDay);
            act.FechaCreada = hora;

            var usuario = _context._Usuarios.Include(u => u.Incendio).FirstOrDefault(u => u.idUsuario == idUsuario);
            act.Incendio = usuario.Incendio;

            _context.Add(act);
            _context.SaveChanges();

            return RedirectToAction("Index");
            //return View("Index");
        }

        [HttpPost]
        public IActionResult BitacoraVerificacionCI(BitacoraVerificacionCI act, Incendio incendios)
        {
            int idUsuario = HttpContext.Session.GetInt32("IdUsuario") ?? 0;
            DateTime fechaActual = DateTime.Now;
            DateTime hora = DateTime.Today.Add(fechaActual.TimeOfDay);
            act.FechaCreada = hora;

            var usuario = _context._Usuarios.Include(u => u.Incendio).FirstOrDefault(u => u.idUsuario == idUsuario);
            act.Incendio = usuario.Incendio;

            var actIncendio = _context.Incendio.FirstOrDefault(u => u.idIncendio == usuario.Incendio.idIncendio);

            actIncendio.Etapa += 1;

            _context.Add(act);
            _context.SaveChanges();
            return RedirectToAction("Index");
            //return View("Index");
        }


        
      

        [HttpPost]
        public IActionResult ActualizarRecurso(int idRecursos)
        {
            int idUsuario = HttpContext.Session.GetInt32("IdUsuario") ?? 0;
            ActualizacionRecursos ActRecurso = new ActualizacionRecursos();

            var obtenerRecurso = _context.Recursos.FirstOrDefault(u => u.IdRecursos == idRecursos);
            DateTime fechaActual = DateTime.Now;
            DateTime hora = DateTime.Today.Add(fechaActual.TimeOfDay);
            var usuario = _context._Usuarios.Include(u => u.Incendio).FirstOrDefault(u => u.idUsuario == idUsuario);

            var incendio = _context.Incendio.FirstOrDefault(u => u.idIncendio == usuario.Incendio.idIncendio);

            obtenerRecurso.Estado = "Vacio";
            ActRecurso.FechaCreada = hora;
            ActRecurso.NombreRecurso = obtenerRecurso.NombreRecurso;
            ActRecurso.NumSerie = obtenerRecurso.NumSerie;
            ActRecurso.Estado = "Vacio";
            ActRecurso.Longitud = obtenerRecurso.Longitud;
            ActRecurso.Latitud = obtenerRecurso.Latitud;
            ActRecurso.Incendio = incendio;



            _context.Add(ActRecurso);
            _context.SaveChanges();
            return RedirectToAction("Index");
        }

    }
}
