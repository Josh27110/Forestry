﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System;

namespace Forestry.Models
{
    public class BitacoraTamanoIncendio
    {
        [Required(ErrorMessage = "IdBitacora")]
        [Key]
        [Display(Name = "IdBitacora")]
        public int IdBitacora { get; set; }

        [Required(ErrorMessage = "FechaCreada")]
        [DataType(DataType.Date)]
        public DateTime FechaCreada { get; set; }

        [MaxLength]
        public string USDA { get; set; }

        [MaxLength]
        public string Estado { get; set; }

        [MaxLength]
        public string DescripcionLocacion { get; set; }

        [Required(ErrorMessage = "FechaLlegada")]
        [DataType(DataType.Date)]
        public DateTime FechaLlegada { get; set; }

        [MaxLength]
        public string Legal { get; set; }

        [MaxLength]
        public string Municipio { get; set; }

        [MaxLength]
        public string Rango { get; set; }

        [MaxLength]
        public string Secciones { get; set; }

        public double Latitud { get; set; }
        public double Longitud { get; set; }

        [MaxLength]
        public string UTM { get; set; }

        [MaxLength]
        public string E { get; set; }

        [MaxLength]
        public string N { get; set; }

        [MaxLength]
        public string ReportadoPor { get; set; }

        public double TamanoEstimado { get; set; }

        public DateTime FechaContencion { get; set; }

        public DateTime FechaControl { get; set; }


        [ForeignKey("IdIncendio")]
        public Incendio Incendio { get; set; }

      //  public virtual Incendio IncendioNavigation { get; set; } = null!;
    }
}
