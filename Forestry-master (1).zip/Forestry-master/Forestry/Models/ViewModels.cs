using Forestry.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Forestry.ViewModels
{
    public class UsuariosReporteViewModel
    {
        public Incendio incendio { get; set; }

        public BitacoraMedidaInicial bitacoraMedidaInicial { get; set; }
    }
}
