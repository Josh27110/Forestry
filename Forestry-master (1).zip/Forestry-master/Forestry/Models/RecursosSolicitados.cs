﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System;

namespace Forestry.Models
{
    public class RecursosSolicitados
    {
        [Required(ErrorMessage = "IdActRecursos")]
        [Key]
        [Display(Name = "IdActRecursos")]
        public int IdRecursoSolicitado { get; set; }

        public DateTime FechaCreada { get; set; }
        public string NombreRecurso { get; set; }

        public int CantidadSolicitada { get; set; }

        [ForeignKey("IdIncendio")]
        public Incendio Incendio { get; set; }

    }
}
