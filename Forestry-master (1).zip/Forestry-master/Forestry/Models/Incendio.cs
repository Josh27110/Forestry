﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System;

namespace Forestry.Models
{
    public class Incendio
    {
        [Required(ErrorMessage = "idIncendio obligatorio")]
        [Key]
        [Display(Name = "idIncendio")]
        public int idIncendio { get; set; }

        [Required(ErrorMessage = "Fecha")]
        [DataType(DataType.Date)]
        [Display(Name = "Fecha")]
        public DateTime FechaIni { get; set; }


        [Required(ErrorMessage = "Fecha")]
        [DataType(DataType.Date)]
        [Display(Name = "Fecha")]
        public DateTime FechaFin { get; set; }

        public int Etapa { get; set; }

        [Required(ErrorMessage = "NombreDespacho obligatorio")]
        [MaxLength]
        [Display(Name = "NombreDespacho")]
        public string NombreDespacho { get; set; }

        [Required(ErrorMessage = "NombreComando obligatorio")]
        [MaxLength]
        [Display(Name = "NombreComando")]
        public string NombreComando { get; set; }


        [ForeignKey("idReporte")]
        public Reporte Reporte { get; set; }

     //   public virtual Reporte ReporteNavigation { get; set; } = null!;
    }
}
