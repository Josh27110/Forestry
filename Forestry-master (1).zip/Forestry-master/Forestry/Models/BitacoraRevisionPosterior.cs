﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System;

namespace Forestry.Models
{
    public class BitacoraRevisionPosterior
    {
        [Required(ErrorMessage = "IdBitacora")]
        [Key]
        [Display(Name = "IdBitacora")]
        public int IdBitacora { get; set; }

        public DateTime FechaCreada { get; set; }
        public string CI { get; set; }
        public string Recursos { get; set; }
        public string CriticadoPor { get; set; }
        public string Comentarios { get; set; }
        public string NombreLider { get; set; }
        public string NombreRevisadoPor { get; set; }

        [ForeignKey("IdIncendio")]
        public Incendio Incendio { get; set; }

     //   public virtual Incendio IncendioNavigation { get; set; } = null!;
    }
}
