using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;


namespace Forestry.Models
{
    public class ContextoBaseDeDatos : DbContext
    {
        public ContextoBaseDeDatos(DbContextOptions<ContextoBaseDeDatos> opt) : base(opt) { }

        public ContextoBaseDeDatos() { }


        public DbSet<Actualizacion> Actualizacion { get; set; }
        public DbSet<Usuarios> _Usuarios { get; set; }
        public DbSet<BitacoraChequeoYPlaneacion> BitacoraChequeoYPlaneacion { get; set; }
        public DbSet<BitacoraMedidaInicial> BitacoraMedidaInicial { get; set; }
        public DbSet<BitacoraRecursos> BitacoraRecursos { get; set; }
        public DbSet<BitacoraRelacionTrabajo> BitacoraRelacionTrabajo { get; set; }
        public DbSet<BitacoraRevisionPosterior> BitacoraRevisionPosterior { get; set; }
        public DbSet<BitacoraStatus> BitacoraStatus { get; set; }
        public DbSet<BitacoraTamanoIncendio> BitacoraTamanoIncendio { get; set; }
        public DbSet<BitacoraVerificacionCI> BitacoraVerificacionCI { get; set; }
        public DbSet<Incendio> Incendio { get; set; }
        public DbSet<Reporte> Reporte { get; set; }
        public DbSet<Recursos> Recursos { get; set; }
        public DbSet<Personal> Personal { get; set; }
        public DbSet<RecursosSolicitados> RecursosSolicitados { get; set; }
        public DbSet<ActualizacionRecursos> ActualizacionRecursos { get; set; }

        public object Usuarios { get; internal set; }
    }
}

