﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System;
using Microsoft.CodeAnalysis;

namespace Forestry.Models
{
    public class Reporte
    {
        [Required(ErrorMessage = "IdReporte")]
        [Key]
        [Display(Name = "IdReporte")]
        public int idReporte { get; set; }

        [ForeignKey("IdUsuario")]
        public Usuarios idUsuario { get; set; }

  
        [Required(ErrorMessage = "Lugar")]
        [MaxLength]
        [Display(Name = "Lugar")]
        public string Lugar { get; set; }

        [Required(ErrorMessage = "Situacion")]
        [MaxLength]
        [Display(Name = "Situacion")]
        public string Situacion { get; set; }

        [Required(ErrorMessage = "Detalles")]
        [MaxLength]
        [Display(Name = "Detalles")]
        public string Detalles { get; set; }

        [Required(ErrorMessage = "Fecha")]
        [DataType(DataType.Date)]
        [Display(Name = "Fecha")]
        public DateTime Fecha { get; set; }


        [Required(ErrorMessage = "Estado")]
        [MaxLength(20)]
        [Display(Name = "Estado")]
        public string Estado { get; set; }

    }
}
