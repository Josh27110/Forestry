﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System;

namespace Forestry.Models
{
    public class Actualizacion
    {
        [Required(ErrorMessage = "idActualizacion obligatorio")]
        [Key]
        [Display(Name = "idActualizacion")]
        public int idActualizacion { get; set; }

        [Display(Name = "Radio")]
        public float Radio { get; set; }

        [Required(ErrorMessage = "Estado obligatorio")]
        [Display(Name = "Latitud")]
        [Column(TypeName = "decimal(18, 15)")]
        public decimal Latitud { get; set; }

        [Required(ErrorMessage = "Estado obligatorio")]
        [Display(Name = "Longitud")]
        [Column(TypeName = "decimal(18, 15)")]
        public decimal Longitud { get; set; }

        [Required(ErrorMessage = "FechaAccion obligatorio")]
        [DataType(DataType.Date)]
        [Display(Name = "FechaAccion")]
        public DateTime FechaAccion { get; set; }

        public string Accion { get; set; }

        public string Tipo { get; set; }

        [Required(ErrorMessage = "IdIncendio obligatorio")]
        [ForeignKey("Incendio")]
        public int idIncendio { get; set; }
        public Incendio Incendio { get; set; }
    //    public virtual Incendio IncendioNavigation { get; set; } = null!;
    }
}
