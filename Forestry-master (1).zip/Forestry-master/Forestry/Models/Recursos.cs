﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System;

namespace Forestry.Models
{
    public class Recursos
    {
        [Required(ErrorMessage = "IdCatalogo")]
        [Key]
        [Display(Name = "IdCatalogo")]
        public int IdRecursos { get; set; }

        public DateTime FechaCreada { get; set; }
        public string NombreRecurso { get; set; }

        public string NumSerie {  get; set; }
        public string Estado {  get; set; }

        [Display(Name = "Latitud")]
        [Column(TypeName = "decimal(18, 15)")]
        public decimal Latitud { get; set; }

        [Display(Name = "Longitud")]
        [Column(TypeName = "decimal(18, 15)")]
        public decimal Longitud { get; set; }

        [ForeignKey("IdIncendio")]
        public Incendio Incendio { get; set; }
    }
}
