﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System;

namespace Forestry.Models
{
    public class Personal
    {
        [Required(ErrorMessage = "IdTrabajador")]
        [Key]
        [Display(Name = "IdTrabajador")]
        public int IdTrabajador { get; set; }

        public DateTime FechaCreada { get; set; }
        public string Nombre { get; set; }

        public string ApPaterno { get; set; }
        public string ApMaterno { get; set; }
        public string Turno { get; set; }

        [ForeignKey("IdUsuarios")]
        public Usuarios Usuarios { get; set; }


    }
}
