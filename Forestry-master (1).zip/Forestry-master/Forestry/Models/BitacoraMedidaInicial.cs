﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System;

namespace Forestry.Models
{
    public class BitacoraMedidaInicial
    {
        [Required(ErrorMessage = "IdBitacora")]
        [Key]
        [Display(Name = "IdBitacora")]
        public int IdBitacora { get; set; }

        [Required(ErrorMessage = "FechaCreada")]
        [DataType(DataType.Date)]
        [Display(Name = "Fecha")]
        public DateTime FechaCreada { get; set; }

        [Required]
        [MaxLength]
        public string Pregunta1 { get; set; }

        [Required]
        [MaxLength]
        public string Pregunta2 { get; set; }

        [Required]
        [MaxLength]
        public string Peligros { get; set; }

        [Required]
        [MaxLength]
        public string PotencialExpansion { get; set; }

        [Required]
        [MaxLength]
        public string CaracterFuego { get; set; }

        [Required]
        [MaxLength]
        public string PendienteFuego { get; set; }

        [Required]
        [MaxLength]
        public string PosicionPendiente { get; set; }

        [Required]
        [MaxLength]
        public string TipoCombustible { get; set; }

        [Required]
        [MaxLength]
        public string CombustiblesAdyacentes { get; set; }

        [Required]
        [MaxLength]
        public string Aspecto { get; set; }

        [Required]
        [MaxLength]
        public string DireccionViento { get; set; }

        [ForeignKey("IdIncendio")]
        public Incendio Incendio { get; set; }

      //  public virtual Incendio IncendioNavigation { get; set; } = null!;
    }
}
