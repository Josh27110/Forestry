using Microsoft.AspNetCore.Http;
using Microsoft.CodeAnalysis;
using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;

namespace Forestry.Models
{
    public class Usuarios
    {
        [Required(ErrorMessage = "IdUsuarios obligatorio")]
        [Key]
        [Display(Name = "IdUsuario")]
        public int idUsuario { get; set; }

        [ForeignKey("idIncendio")]
        public Incendio Incendio { get; set; }

        [Required(ErrorMessage = "Rol obligatorio")]
        [MaxLength(20)]
        [Display(Name = "Rol")]
        public string Rol { get; set; }

        [Required(ErrorMessage = "Estado obligatorio")]
        [MaxLength(20)]
        [Display(Name = "Estado")]
        public string Estado { get; set; }

        [Required(ErrorMessage = "Nombre obligatorio")]
        [MaxLength(20)]
        [Display(Name = "Nombre")]
        public string Nombre { get; set; }

        [Required(ErrorMessage = "ApMaterno obligatorio")]
        [MaxLength(20)]
        [Display(Name = "ApMaterno")]
        public string ApMaterno { get; set; }


        [Required(ErrorMessage = "ApPaterno obligatorio")]
        [MaxLength(20)]
        [Display(Name = "ApPaterno")]
        public string ApPaterno { get; set; }

        [MaxLength(20)]
        [Display(Name = "NumeTel")]
        public string NumeTel { get; set; }

        [Required(ErrorMessage = "Usuario obligatorio")]
        [MaxLength(20)]
        [Display(Name = "Usuario")]
        public string Usuario { get; set; }

        [Required(ErrorMessage = "Contrasena obligatorio")]
        [MaxLength(256)]
        [Display(Name = "Contrasena")]
        [DataType(DataType.Password)]
        public string Contrasena { get; set; }

        public string DiasLaborales {  get; set; }

        
        public TimeSpan TrabajoInicio { get; set; }
        public TimeSpan TrabajoFin {  get; set; }


    }
}
