﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System;

namespace Forestry.Models
{
    public class ActualizacionRecursos
    {
        [Required(ErrorMessage = "IdActRecursos")]
        [Key]
        [Display(Name = "IdActRecursos")]
        public int IdActRecursos { get; set; }

        public DateTime FechaCreada { get; set; }
        public string NombreRecurso { get; set; }
        public string NumSerie { get; set; }
        public string Estado { get; set; }

        [Display(Name = "Latitud")]
        [Column(TypeName = "decimal(18, 15)")]
        public decimal Latitud { get; set; }

        [Display(Name = "Longitud")]
        [Column(TypeName = "decimal(18, 15)")]
        public decimal Longitud { get; set; }

        [ForeignKey("IdIncendio")]
        public Incendio Incendio { get; set; }

    }
}
