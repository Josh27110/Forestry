﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System;

namespace Forestry.Models
{
    public class BitacoraRelacionTrabajo
    {
        [Required(ErrorMessage = "IdBitacora")]
        [Key]
        [Display(Name = "IdBitacora")]
        public int IdBitacora { get; set; }


        public DateTime FechaCreada { get; set; }
        public string Recurso { get; set; }
        public DateTime FechaInicio { get; set; }
        public DateTime FechaTermino { get; set; }
        public double HorasTrabajadas { get; set; }
        public double HorasDescansadas { get; set; }

        [ForeignKey("IdIncendio")]
        public Incendio Incendio { get; set; }

     //   public virtual Incendio IncendioNavigation { get; set; } = null!;
    }
}
