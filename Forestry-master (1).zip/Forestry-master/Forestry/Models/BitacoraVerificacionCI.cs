﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System;

namespace Forestry.Models
{
    public class BitacoraVerificacionCI
    {
        [Required(ErrorMessage = "IdBitacora")]
        [Key]
        [Display(Name = "IdBitacora")]
        public int IdBitacora { get; set; }

        [Required]
        public DateTime FechaCreada { get; set; }

        [MaxLength]
        public string Pregunta1 { get; set; }

        [MaxLength]
        public string Pregunta2 { get; set; }

        [MaxLength]
        public string Pregunta3 { get; set; }

        [MaxLength]
        public string Pregunta4 { get; set; }

        [MaxLength]
        public string Pregunta5 { get; set; }

        [MaxLength]
        public string Pregunta6 { get; set; }

        [MaxLength]
        public string Pregunta7 { get; set; }

        [MaxLength]
        public string Pregunta8 { get; set; }

        [MaxLength]
        public string Pregunta9 { get; set; }

        [MaxLength]
        public string NombreFirma { get; set; }

        [ForeignKey("IdIncendio")]
        public Incendio Incendio { get; set; }

      //  public virtual Incendio IncendioNavigation { get; set; } = null!;
    }
}
