using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using Microsoft.EntityFrameworkCore;
//using Forestry.Repositories;
using Forestry.Models;
using Microsoft.Extensions.Options;
using Microsoft.AspNetCore.Identity;

namespace Forestry
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddAuthentication("CookieAuth").AddCookie("CookieAuth", configuraciones => {

                configuraciones.Cookie.Name = "Forestry";
                configuraciones.ExpireTimeSpan = TimeSpan.FromDays(1);
                configuraciones.LoginPath = "/Home/Login";
                configuraciones.AccessDeniedPath = "/Home/AccesDenied";
            });

            services.ConfigureApplicationCookie(options =>
            {
                options.ExpireTimeSpan = TimeSpan.FromDays(10);
            });

            services.AddControllersWithViews();

            services.AddDbContext<ContextoBaseDeDatos>(opt =>
            {
                //Recuerda modificar la cadena de conexi�n, esta puede variar cada vez que cambias de equipo
                //Despues realiza la migraci�n con database-update
                opt.UseSqlServer(Configuration.GetConnectionString("DefaultConnection"));
            });

            services.AddHttpContextAccessor();

            //-------------------------------
            services.AddSession(options =>
            {
                options.Cookie.Name = ".YourApp.Session";
                options.IdleTimeout = TimeSpan.FromMinutes(20); // Puedes ajustar el tiempo de expiraci�n seg�n tus necesidades
                options.Cookie.HttpOnly = true;
                options.Cookie.IsEssential = true;
            });

            // Otros servicios
            services.AddControllersWithViews();
            // Otros servicios

        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                //app.UseHsts();
            }

            //app.UseHttpsRedirection(); //checar
            app.UseStaticFiles();

            app.UseSession();

            app.UseRouting();
            app.UseAuthentication();
            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllerRoute(
                    name: "default",
                    pattern: "{controller=Home}/{action=Privacy}/{id?}");
            });

        }
    }
}
