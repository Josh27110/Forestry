﻿// Función para limpiar la firma en el lienzo especificado
function limpiarFirma(canvasId) {
    var canvas = document.getElementById(canvasId);
    var contexto = canvas.getContext('2d');
    contexto.clearRect(0, 0, canvas.width, canvas.height);
}

// Función para inicializar el lienzo de firma
function inicializarFirma(canvasId) {
    var canvas = document.getElementById(canvasId);
    var contexto = canvas.getContext('2d');

    // Inicializar propiedades de dibujo
    contexto.lineWidth = 2;
    contexto.lineCap = 'round';
    contexto.strokeStyle = '#000000';

    var dibujando = false;
    var lastX = 0;
    var lastY = 0;

    // Función para comenzar a dibujar
    function empezarDibujo(e) {
        dibujando = true;
        [lastX, lastY] = [e.offsetX, e.offsetY];
    }

    // Función para dibujar durante el movimiento del ratón/táctil
    function dibujar(e) {
        if (!dibujando) return;
        contexto.beginPath();
        contexto.moveTo(lastX, lastY);
        contexto.lineTo(e.offsetX, e.offsetY);
        contexto.stroke();
        [lastX, lastY] = [e.offsetX, e.offsetY];
    }

    // Función para terminar el dibujo
    function terminarDibujo() {
        dibujando = false;
    }

    // Agregar event listeners para los eventos de dibujo
    canvas.addEventListener('mousedown', empezarDibujo);
    canvas.addEventListener('mousemove', dibujar);
    canvas.addEventListener('mouseup', terminarDibujo);
    canvas.addEventListener('mouseout', terminarDibujo);

    // Eventos de pantalla táctil
    canvas.addEventListener('touchstart', function (e) {
        empezarDibujo(e.touches[0]);
    });
    canvas.addEventListener('touchmove', function (e) {
        dibujar(e.touches[0]);
    });
    canvas.addEventListener('touchend', terminarDibujo);
}
