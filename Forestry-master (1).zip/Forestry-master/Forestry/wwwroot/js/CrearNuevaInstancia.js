﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.

document.addEventListener("DOMContentLoaded", function () {
    var selectElement = document.getElementById("PreguntaEspecifica");
    var textareaElement = document.getElementById("especificar");

    selectElement.addEventListener("change", function () {
        if (this.value === "si") {
            textareaElement.style.display = "block";
            textareaElement.classList.add("placeholder");
        } else {
            textareaElement.style.display = "none";
            textareaElement.classList.remove("placeholder");
        }
    });
});

document.getElementById("combustible").addEventListener("change", function () {
    var textareaElement = document.getElementById("otros-combustible");
    if (this.value === "Otros") {
        textareaElement.style.display = "block";
        textareaElement.classList.add("placeholder");
    } else {
        textareaElement.style.display = "none";
        textareaElement.classList.remove("placeholder");
    }
});
