﻿
    $(document).ready(function() {
        $('#MedidaInicialIncendio').on('submit', function(event) {
            event.preventDefault(); // Previene el envío por defecto del formulario

            // Construye un objeto JSON estructurado
            var jsonData = {
                estructuraEnPeligro: {
                    respuesta: $('select[name="PreguntaEspecifica"]').eq(0).val(),
                    especificar: $('textarea[name="especificar"]').eq(0).val()
                },
                problemaDeControl: {
                    respuesta: $('select[name="PreguntaEspecifica"]').eq(1).val(),
                    especificar: $('textarea[name="especificar"]').eq(1).val()
                },
                recursosAdicionales: {
                    respuesta: $('select[name="PreguntaEspecifica"]').eq(2).val(),
                    especificar: $('textarea[name="especificar"]').eq(2).val()
                },
                peligros: $('input[name="usuario"]').eq(0).val(),
                potencialDeExpansion: $('select[name="PotencialDeExpansion"]').val(),
                caracterDelFuego: $('select[name="CaracterDelFuego"]').val(),
                pendienteEncabezaFuego: $('select[name="PendienteEncabezaFuego"]').val(),
                posicionPendiente: $('select[name="PosicionPendiente"]').val(),
                tipoDeCombustible: {
                    tipo: $('select[name="TipoDeCombustible"]').val(),
                    otros: $('textarea[name="otros-combustible"]').val()
                },
                combustiblesAdyacentes: $('select[name="CombustiblesAdyacentes"]').val(),
                porcentajePerimetroActivo: $('input[name="usuario"]').eq(1).val(),
                aspecto: $('select[name="Aspecto"]').val(),
                velocidadViento: $('input[name="usuario"]').eq(2).val(),
                direccionViento: $('select[name="DireccionViento"]').val(),
                tipoDeCombustibleERC: $('input[name="usuario"]').eq(3).val(),
                relacionPercentil90: $('input[name="usuario"]').eq(4).val()
            };

            var jsonString = JSON.stringify(jsonData); // Convierte el objeto JSON a una cadena JSON
            console.log(jsonString); // Muestra la cadena JSON en la consola

            // Aquí puedes enviar la cadena JSON a tu servidor usando AJAX si es necesario
            /*
            $.ajax({
                url: '/Home/SaveJsonData',
                type: 'POST',
                contentType: 'application/json',
                data: jsonString,
                success: function(response) {
                    // Maneja la respuesta del servidor
                    console.log('Success:', response);
                },
                error: function(error) {
                    // Maneja el error
                    console.log('Error:', error);
                }
            });
            */
        });
    });


